<section class="fabout">
		<div class="section white center">
		      <div class="row container">
		        <h2 class="header">ABOUT US</h2>
		        <p class="grey-text text-darken-3 lighten-3">Bavika's Red Velvet is a bakery and cake shop in Visakhapatnam that was started in 2019.
					 We have three branches in the city and specialize in cakes, pastries, and other baked goods. 
					We also serve a variety of North Indian, South Indian, snacks, Himalayan, and Chinese dishes. 
					We are committed to providing our customers with high-quality food and excellent service. 
					Our team of experienced bakers and chefs are passionate about creating delicious and innovative dishes. 
					We are committed to using only the freshest ingredients in our food. We offer a variety of catering options for events of all sizes. 
					We have a friendly and welcoming atmosphere.</p>
		      </div>
	</section>